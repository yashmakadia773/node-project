let express = require("express");
const { blogController } = require("../controller");
let route = express.Router();

route.get("/getBlog", blogController.getBlog);
route.post("/addBlog", blogController.addBlog);
route.delete("/deleteBlog", blogController.deleteBlog);
route.put("/updateBlog", blogController.updateBlog);

module.exports = route;