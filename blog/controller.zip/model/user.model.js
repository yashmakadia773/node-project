let mongoose = require("mongoose");

let userSchema = new mongoose.Schema({
  profile: {
    type: String,
  },
  firstName: {
    type: String,
    required: true,
  },
  lastName: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
  },
  password: {
    type: String,
    required: true,
  },
  role: {
    type: String,
    enum: ["admin", "user"],
    default: "user",
  },
});

let userData = mongoose.model("userSchema", userSchema);

module.exports = userData;
