module.exports.userSchema = require("./user.model");
module.exports.blogSchema = require("./blog.model");
